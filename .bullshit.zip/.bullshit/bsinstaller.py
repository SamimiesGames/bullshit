import sys
import compiler
import os


def fopen(cmds: list):
    process([f"{cmds[0]}", "build", f"{cmds[1]}", "1024", "quiet"])
    os.startfile("rev/test.py")


def ui():
    os.system(f"title Bullshit: {compiler.version}")
    print(f"Bullshit: {compiler.version}\ntype run to execute.")
    while True:
        source = ""
        while True:
            prompt = input(">>>")
            if prompt == "run":
                break
            elif prompt == "exit":
                exit(0)
            else:
                source += prompt
        try:
            print(source)
            compiler.PyCompile(source, name="run.py", quiet=True)
            exec(open("run.py", "r").read(), {})
        except Exception as e:
            print("Error:", e)
            continue


def process(cmds: list):

    cmds = [x for x in cmds if cmds.index(x) != 0]
    tasks = []
    quiet = False
    uv_file = None
    i = 0

    while i < len(cmds):
        cmd = cmds[i]
        if cmd == "build":
            tasks.append({"id": "build", "file": cmds[i + 1], "size": cmds[i + 2], "cmod": cmds[i+3]})
            i += 3
        elif cmd == "quiet":
            quiet = True
            i += 1
        elif cmd == "ui":
            tasks.append({"id": "uiopen"})
            i += 1
        elif cmd == "run":
            tasks.append({"id": "run"})
        else:
            print(f"Invalid argument: \"{cmds[i]}\" ")
            exit()
        i += 1

    for task in tasks:
        id_ = task["id"]
        if id_ == "build":
            if task["cmod"] == "py":
                print("[bsinstaller] using py compiler\n")
                compiler.PyCompile(open(task["file"]).read(), task["size"], quiet)
                uv_file = "test.py"
            elif task["cmod"] == "cs":
                print("[bsinstaller] using cs compiler\n")
                compiler.CSCompile(open(task["file"]).read(), task["size"], quiet)
                uv_file = "test.cs"
        elif id_ == "uiopen":
            ui()
        elif id_ == "run":
            if uv_file is not None:
                print("[bsinstaller] starting \"%s\"" % uv_file)
                os.startfile(uv_file)
            else:
                print("[bsinstaller] Depricating argument \"run\", because no file has been compiled.")
        else:
            print(f"Unknown task: \"{id_}\" ")


process(sys.argv)
