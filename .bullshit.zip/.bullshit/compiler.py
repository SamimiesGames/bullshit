import time

indenting = 4
padding = ""
pyhooks = {
    "<": ["i -= 1", 0],
    ">": ["i += 1", 0],
    "+": ["ram[i] += 1", 0],
    "-": ["ram[i] -= 1", 0],
    ".": ["print(ram[i])", 0],
    ",": ["ram[i] = input(chr(ram[i]))", 0],
    "^": ["ram[i] *= ram[i]", 0],
    "~": ["ram[i] = round(ram[i])", 0],
    "/": ["ram[i] /= ram[i]", 0],
    "u": ["ram[i] = chr(ram[i])", 0],
    "n": ["ram[i] = ord(ram[i])", 0],
    "|": ["print(chr(ram[i]))", 0],
    ":": ["ram[i] *= 2", 0],
    "r": ["ram[i] = 0", 0],
    "[": ["while ram[i] >= 0:", indenting],
    "]": ["", -indenting],
    "{": ["def f%s():", indenting],
    "}": ["\nram[i] = f%s", -indenting],
    "$": ["ram[i]()", 0]
}
cshooks = {
    "<": ["i -= 1", 0],
    ">": ["i += 1", 0],
    "+": ["ram[i] += 1", 0],
    "-": ["ram[i] -= 1", 0],
    ".": ["Console.Write(ram[i])", 0],
    ",": ["ram[i] = Console.Read()", 0],
    "^": ["ram[i] *= ram[i]", 0],
    "~": ["ram[i] = Math.floor(ram[i])", 0],
    "/": ["ram[i] /= ram[i]", 0],
    ":": ["ram[i] *= 2", 0],
    "r": ["ram[i] = 0", 0],
    "[": ["while(ram[i] >= 0) {", indenting],
    "]": ["}", -indenting]
}
ignore = ["\n", "\f", "\t", " "]
tag = 0
py_microprogram = """
i = 0
ram = {x: x-x for x in range(%s)}

"""
cs_microprogram = """
%sint i = 0;
%sint[] ram = new int[%s];

"""
cs_suffix_microprogram = """
using System;

public class Program()
{
    public static void Main()
    {
        %s
    }
}
"""
version = "v1.0"


def updatepadding(i):
    next_padding = padding

    if i > 0:
        for x in range(indenting):
            next_padding += " "
    elif i == 0:
        pass
    else:
        next_padding = next_padding[0:len(next_padding)-indenting]

    return next_padding


class PyCompile:
    def __init__(self, source: str, memorysize: int = 1024, quiet: bool = False,
                 name: str = "test.py"):
        self.quiet = quiet

        self.log("setting up ... ")

        self.src = source
        incomment = False
        depricated_source = ""

        for s in self.src:
            if s == "#" and not incomment:
                incomment = True
            elif s == "\n" and incomment:
                incomment = False

            if incomment:
                pass
            else:
                depricated_source += s

        self.src = depricated_source

        for s in ignore:
            self.src = self.src.replace(s, "")

        self.siz = memorysize
        self.name = name
        self.file = open(self.name, "a")
        self.file.truncate(0)
        self.run()

    def log(self, item: any):
        if not self.quiet:
            print(str(item))
        else:
            pass

    def run(self) -> None:
        global padding
        global tag

        self.log("compiling ... ")

        monotonic = time.time()
        self.file.write(py_microprogram % self.siz)
        i = 0

        for letter in self.src:
            try:
                i += 1
                translated = pyhooks[letter]
            except KeyError:
                raise SystemExit(f"SyntaxError: incorrect syntax: \"{letter}\" is not a keyword. In letter: \"{i}\" ")

            if translated[0] == "def f%s():":
                translated[0] = "\n" + translated[0] % tag + f"\n{' ' * indenting}global i"
                tag += 1
            elif translated[0] == "\nram[i] = f%s":
                translated[0] = translated[0] % (tag - 1)

            self.file.write(padding + translated[0] + "\n")
            padding = updatepadding(translated[1])

        self.file.close()
        self.log(f"Finished in: {time.time()-monotonic}(s)")


class CSCompile:
    def __init__(self, source: str, memorysize: int = 1024, quiet: bool = False,
                 name: str = "test.cs"):
        self.quiet = quiet

        self.log("setting up ... ")

        self.src = source
        incomment = False
        depricated_source = ""

        for s in self.src:
            if s == "#" and not incomment:
                incomment = True
            elif s == "\n" and incomment:
                incomment = False

            if incomment:
                pass
            else:
                depricated_source += s

        self.src = depricated_source

        for s in ignore:
            self.src = self.src.replace(s, "")

        self.siz = memorysize
        self.name = name
        self.file = open(self.name, "a")
        self.file.truncate(0)
        self.run()

    def log(self, item: any):
        if not self.quiet:
            print(str(item))
        else:
            pass

    def run(self) -> None:
        global padding
        global tag

        self.log("compiling ... ")
        default = (" " * 8)

        monotonic = time.time()
        translation = cs_microprogram % (default, default, self.siz)
        i = 0

        for letter in self.src:
            try:
                i += 1
                translated = cshooks[letter]
            except KeyError:
                raise SystemExit(f"SyntaxError: incorrect syntax: \"{letter}\" is not a keyword. In letter: \"{i}\" ")

            translation += default + padding + translated[0] + (";\n" if translated[1] != indenting else "\n")
            padding = updatepadding(translated[1])

        translation = cs_suffix_microprogram % translation

        self.file.write(translation)
        self.file.close()

        self.log(f"Finished in: {time.time()-monotonic}(s)")
